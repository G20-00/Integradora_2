package model;
public enum EnumGenre {
	
	ROCK, HIP_HOP,MUSICA_CLASICA,REGGAE, SALSA
	
}