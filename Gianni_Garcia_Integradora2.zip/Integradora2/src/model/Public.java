package model;
public class Public extends PlayList{
	private double calificacion; 
	private int countain;
	/**
	 * Constructor
	 * @param name is a String
	 * @param durattion is a int
	 * @param genre is a String
	 * @param qualification is a double
	 */
	public Public(String nombre,int duraccion,String genre,double calificacion){
		super(nombre,duraccion,genre);
		this.calificacion = calificacion;
		countain = 0;
		super.time();
	}
	//getters 
	public double getCalificacion(){
		return calificacion;
	}
		@Override
	public String showList(){
		String out = "";
		out =("\n******PlayList******"+"\n**Nombre de la playList :"+ getName() + "\n**Duraccion :" +time ()+"\n**Generos :"+getGenre()
		+"\n**Calificacion :"+qualification()+"\n********************"	);
		return out;
	}
	@Override
	public String showLists(){
		String out = "";
		out =("******PlayList******"+"\n**Nombre de la playList :"+ getName());
		return out;
	}
	@Override
	public void changeRaiting(int qualification){
		calificacion+= qualification;
		countain++;
		
		
	}	
	public double qualification(){
		double out= calificacion/countain;
		return out;
	}
	
}